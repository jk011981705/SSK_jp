package com.example.client;

public interface OnPathChangedListener {
	
	public void onChanged(String path);

}

