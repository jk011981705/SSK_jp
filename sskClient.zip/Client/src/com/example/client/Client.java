package com.example.client;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.*;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.content.Intent;

import java.io.*;
import java.net.*;

import android.widget.Toast;
import android.annotation.SuppressLint;
import android.view.KeyEvent;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class Client extends Activity {

	private String serverIP = "10.200.38.209";
	private String serverPortm;
	private int serverPort = 5555;
	static int kill = 0;
	Socket sock = null;
	Thread thread;
	File file;
	static String filena = "test.txt";
	String extention;
	static boolean chk = false;
	TextView FilePath, ipText, portText;
	//static FileList _FileList;
	// 경로지정 다이얼로그
	private Context mct=this;

	private AsyncTask<Integer, String, Integer> mProgressDlg;
	// ---

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		FilePath = (TextView) findViewById(R.id.FilePath);
		ipText = (TextView) findViewById(R.id.IpText);
		portText = (TextView) findViewById(R.id.PortText);

		Button setButton = (Button) findViewById(R.id.SetButton);
		
		
		// 설정버튼
		setButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				serverIP = ipText.getText().toString();
				serverPortm = portText.getText().toString();
				
				
				//Intent intent = new Intent(mct, Filetrans.class);
				
				
				//intent.putExtra("Ip", serverIP);
				//intent.putExtra("Port", serverPortm);
				
				//serverPort = Integer.parseInt(serverPortm);
/*
				try {
					sock = new Socket(serverIP, serverPort);
				} catch (UnknownHostException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}*/
				//startActivity(intent);
			}
		});
		
		
		
		Button sendButton = (Button) findViewById(R.id.SendButton);

		// 설정버튼
		sendButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				if (chk == false) {
					chk = true;
					thread = new Thread(new ClientTest());
					thread.start();
				}

			}
		});

		//_FileList = new FileList(this);

		/*
		_FileList.setOnPathChangedListener(new OnPathChangedListener() {
			public void onChanged(String path) {
				FilePath.setText(".." + path);
			}
		});

		_FileList.setOnFileSelected(new OnFileSelectedListener() {
			public void onSelected(String path, String fileName) {
				FilePath.setText(".." + path + fileName);
				filena = fileName;
				if (chk == false) {
					chk = true;
					thread = new Thread(new ClientTest());
					thread.start();
				}

				// Log.i("filena", filena);
			}
		});*/

		//LinearLayout layout = (LinearLayout) findViewById(R.id.LinearLayout01);
		//layout.addView(_FileList);

		//_FileList.setPath("/sdcard");
		//_FileList.setFocusable(true);
		//_FileList.setFocusableInTouchMode(true);
	}

	class ClientTest implements Runnable {

		@Override
		public void run() {
			// TODO Auto-generated method stub
			while (chk == true) {
				try {
					chk = false;
					serverPort = Integer.parseInt(serverPortm);

					sock = new Socket(serverIP, serverPort);
					BufferedOutputStream toServer = null;
					BufferedInputStream bis = null;
					FileInputStream fis = null;
					DataOutputStream dos = null;

					try {

						file = new File("sdcard/Documents/test.txt");// 파일 이름 지정

						toServer = new BufferedOutputStream(sock.getOutputStream());
						dos = new DataOutputStream(sock.getOutputStream());
						dos.writeUTF(file.getName());

						fis = new FileInputStream(file);
						bis = new BufferedInputStream(fis);

						byte[] buffer = new byte[1024];
						int length_size = 0;

						while (true) {
							length_size = bis.read(buffer);
							if (length_size == -1)
								break;
							toServer.write(buffer, 0, length_size);
							toServer.flush();
						}

						toServer.flush();

						bis.close();
						fis.close();
						dos.close();
						toServer.close();

						sock.close();
						thread.wait();

					} catch (Exception e) {
						e.printStackTrace();
					} finally {
						sock.close();
					}

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

	}

	public void _finish() {
		moveTaskToBack(true);
		finish();
		android.os.Process.killProcess(android.os.Process.myPid());
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) { // 뒤로가기 키를 눌렀을때
		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
			if (kill == 0) {
				kill++;
				Toast.makeText(this, "종료하시려면 한 번 더 누르세요", Toast.LENGTH_SHORT).show();
			} else
				_finish();
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

}
