package com.example.client;

public interface OnFileSelectedListener {
	
	public void onSelected(String path, String fileName);

}
