/**
 * 
 */
package com.example.client;

import java.io.*;
import java.net.*;

import org.w3c.dom.*;

import com.example.client.Client.*;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.widget.*;

/**
 * @author Sohnsungmin
 *
 */
public class Filetrans extends Activity {

	/* (non-Javadoc)
	* @see android.app.Activity#onCreate(android.os.Bundle)
	*/
	
	
}
