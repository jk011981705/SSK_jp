import java.util.GregorianCalendar;

public class Today extends Server{

	// 현재 날짜
	public Today() {

		GregorianCalendar calender = new GregorianCalendar();
		int year, month, date, amPm, hour, min, sec;

		year = calender.get(calender.YEAR);
		month = calender.get(calender.MONTH);
		date = calender.get(calender.DATE);
		amPm = calender.get(calender.AM_PM);
		hour = calender.get(calender.HOUR);
		min = calender.get(calender.MINUTE);
		sec = calender.get(calender.SECOND);
		String sAmPm = amPm == calender.AM ? "오전" : "오후";
		String dd = year + "년 " + month + "월 " + date + "일  " + sAmPm + " "
				+ hour + "시 " + min + "분 " + sec + "초";
		log.append(dd + "\n");
	}
    
    public static void main(String[] args) {
    	new Today();
    }
}