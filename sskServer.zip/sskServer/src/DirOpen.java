import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class DirOpen extends Server {

	//저장 폴더 열기
	public DirOpen(){
		
		String tem = Path.replace("\\", "/");	//폴더 경로 문자열을 치환하여 저장
		
		try {

		    // 자바에서 cmd 실행 내부명령으로 저장 폴더 열기
		    Process processCmd = new ProcessBuilder("cmd", "/c", "start "+ tem, "/?").start();
			  
		    // 외부 프로그램 출력 읽기
		    BufferedReader stdOut   = new BufferedReader(new InputStreamReader(processCmd.getInputStream()));
		    BufferedReader stdError = new BufferedReader(new InputStreamReader(processCmd.getErrorStream()));

		  } catch (IOException e) {
		      System.exit(-1);
		    }
	
	}
    
    public static void main(String[] args) {
    	new DirOpen();
    }
}