import java.io.File;

import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;

public class DirSelect extends Server {

	// 파일 경로 탐색기
	public DirSelect() {
		JFileChooser chooser = new JFileChooser();
		chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		FileFilter filter = new FileNameExtensionFilter("java folder", "java");
		chooser.addChoosableFileFilter(filter);

		int value = chooser.showOpenDialog(null);
		if (value == JFileChooser.APPROVE_OPTION) {

			File selFile = chooser.getSelectedFile();
			Path = selFile + "";
			lb2.setText(Path);
		}
	}
    
    public static void main(String[] args) {
        new DirSelect();
    }
}