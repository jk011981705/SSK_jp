import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.io.*;
import java.awt.dnd.*;
import java.awt.*;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

public class Server implements Runnable, ActionListener{

	public static int serverPort;

	// 다운 경로
	static String Path = "C:\\Users\\Sohnsungmin\\Desktop\\원본";

	Socket socket;

	// GUI
	static JPanel panel = new JPanel();
	static JTextArea log = new JTextArea();
	static JScrollPane logScroll = new JScrollPane(log);
	static JProgressBar progress = new JProgressBar();
	static JLabel lb2 = new JLabel(Path);

	static double fileSize = 0;
	
	@Override
	public void run() {
		

		try {

			serverPort = (int) (Math.random() * 9999);

			log.append("아이피 주소 : "
					+ InetAddress.getLocalHost().getHostAddress() + "\n");
			log.append("포트번호 : " + serverPort + "\n");
			log.append("대기중.. \n \n");

			// 서버 소켓 생성
			ServerSocket serverSocket = new ServerSocket(serverPort);

			// 클라이언트와 연결 대기 루프
			while (true) {

				// 클라이언트와 연결될 때까지 대기
				socket = serverSocket.accept();
				log.append("Client와 연결\n");

				new Today();

				log.append("수신중.... \n");

				try {
					// 파일명 받기
					

					// 파일크기
				

					// 파일명 처리

					// 파일 크기 처리
					// 받을 원본 파일의 총 사이즈

					// 현재 진행 중인 파일의 사이즈 변수

					// 파일 생성하고 파일에 대한 출력 스트림 생성
					
					
					BufferedInputStream up = new BufferedInputStream(socket.getInputStream());
					DataInputStream dis = new DataInputStream(up);

					
					String str = dis.readUTF();

					log.append("수신중인 파일 이름 : " + str + "\n");
					// 1KB씩 데이터를 전송 받으면서 기록
					File f = new File(Path, str);
					

					FileOutputStream output = new FileOutputStream(f);
					BufferedOutputStream outFile = new BufferedOutputStream(output);
					
					byte[] buf = new byte[1024];
					int length_size = 0;
					while (true) {
						
						length_size = up.read(buf);
						if(length_size==-1)break;
						
						outFile.write(buf, 0, length_size);
						outFile.flush();


					}
					
					outFile.flush();
					
					outFile.close();
					output.close();
					dis.close();
					up.close();
					socket.close();
					
					log.append(str + " 수신완료" + "\n \n");

				} catch (Exception e) {

					log.append("서버 에러!! \n");

					e.printStackTrace();
				}

				finally {

					int result = JOptionPane.showConfirmDialog(null, "다운로드가 완료되었습니다.",
							"다운로드 완료", JOptionPane.YES_NO_OPTION);
					if(result==JOptionPane.NO_OPTION){socket.close();
					System.exit(0);}
					socket.close();
				}

			} // End while

		}

		catch (Exception e) {
			e.printStackTrace();
		}

	} // End of Run

	public static void main(String[] argv) {

		// GUI
		frameCreate();

		log.append("\n서버를 실행 시켜 주세요\n \n");

	}

	// 프로그램 GUI
	static void frameCreate() {

		// - 전체적 화면 설정 -
		JFrame f = new JFrame(
				"SSK : 쓱 (WiFi Based Data Transmission)");
		f.setSize(700, 500);
		f.getContentPane().setBackground(SystemColor.window);
		
		// 현재 모니터의 크기 알아내기
		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		// 프레임의 사이즈 알아내기
		Dimension f_size = f.getSize();
		// 모니터 정중앙으로 화면의 크기를 계산하여 보이기
		int xpos = (int) (screen.getWidth() / 2 - f_size.getWidth() / 2);
		int ypos = (int) (screen.getHeight() / 2 - f_size.getHeight() / 2);
		// 프레임 크기 고정시키기
		f.setResizable(true);
		// 프레임 보여지기 - 기본값 false
		f.setVisible(true);
		// 윈도우 종료
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		// 프레임 나타날 위치 지정하는 메소드
		f.setLocation(xpos, ypos);
		// 배치관리자 제거
		f.setLayout(null);

		// - 메뉴 설정 -
		// 메뉴바 생성
		JMenuBar menubar1 = new JMenuBar();
		f.setJMenuBar(menubar1);

		// - log 보여주기 -
		log.setEnabled(false); // 수정 못하게 함

		log.setCaretColor(Color.white);
		log.setBackground(Color.black);
		logScroll.getVerticalScrollBar().addAdjustmentListener(
				new AdjustmentListener() {
					public void adjustmentValueChanged(AdjustmentEvent e) {
						JScrollBar jBar = (JScrollBar) e.getSource();
						jBar.setValue(jBar.getMaximum());
					}

				});
		logScroll.setBounds(20, 30, 640, 300);
		f.add(logScroll);
		
		JLabel lb1 = new JLabel("다운로드 경로 : ");
		lb1.setFont(new Font("돋움", Font.PLAIN, 17));
		lb1.setBounds(20, 350, 132, 18);
		f.getContentPane().add(lb1);
		
		lb2.setFont(new Font("돋움", Font.PLAIN, 17));
		lb2.setBounds(150, 350, 400, 18);
		f.getContentPane().add(lb2);
		
		JButton btn1 = new JButton("파일저장경로지정");
		btn1.setBorderPainted(false);
		btn1.setFont(new Font("돋움", Font.PLAIN, 17));
		btn1.setForeground(new Color(255, 255, 255));
		btn1.setBackground(new Color(192, 0, 0));
		btn1.setBounds(20, 400, 200, 30);
		f.getContentPane().add(btn1);
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new DirSelect();
			}
		});
		
		JButton btn2 = new JButton("저장폴더 열기");
		btn2.setBorderPainted(false);
		btn2.setFont(new Font("돋움",Font.PLAIN, 17));
		btn2.setForeground(new Color(255, 255, 255));
		btn2.setBackground(new Color(244, 146, 1));
		btn2.setBounds(240, 400, 200, 30);
		f.getContentPane().add(btn2);
		btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new DirOpen();

			}
		});
		
		JButton btn3 = new JButton("서버 실행");
		btn3.setBorderPainted(false);
		btn3.setFont(new Font("돋움", Font.PLAIN, 17));
		btn3.setForeground(new Color(255, 255, 255));
		btn3.setBackground(new Color(21, 159, 132));
		btn3.setBounds(460, 400, 200, 30);
		f.getContentPane().add(btn3);
		btn3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				threadStart();
			}
		});


	}
	
	static void fileSelect() {
		JFileChooser chooser = new JFileChooser();
		FileFilter filter = new FileNameExtensionFilter("java file", "java");
		chooser.addChoosableFileFilter(filter);

		int value = chooser.showOpenDialog(null);
		if (value == JFileChooser.APPROVE_OPTION) {

			log.append("전송할 파일 경로 : " + Path + "\n \n");
			
		}
		
	}
	

	// 실행 - run() 실행
	static void threadStart() {

		Thread serv = new Thread(new Server());
		serv.start();
	}

	// 메뉴 액션
	public void actionPerformed(ActionEvent e) {

	}


	public void dropActionChanged(DropTargetDragEvent dtde) {

	}

}
